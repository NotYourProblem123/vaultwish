package com.vaultwish;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.vault.VaultBlockEntity;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VaultWishClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("vaultwish");

    private BlockPos lastMatchPos = null;
    private long nextAutoUse = 0;

    @Override
    public void onInitializeClient() {
        WishList.load();
        registerCommands();

        // 1) Alert when the vault you look at shows a wanted item
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null || mc.level == null) return;
            if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) {
                lastMatchPos = null;
                return;
            }
            BlockPos pos = hit.getBlockPos();
            ItemStack shown = displayedAt(mc.level, pos);
            if (shown.isEmpty()) {
                lastMatchPos = null;
                return;
            }
            if (WishList.contains(idOf(shown))) {
                mc.player.displayClientMessage(
                        Component.literal("\u2605 WANTED: ").append(shown.getHoverName())
                                .append(Component.literal(" \u2014 use your key NOW!")), true);
                if (!pos.equals(lastMatchPos)) {
                    mc.player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
                    lastMatchPos = pos;
                }
                // Auto-use: spend the key by itself when the wanted item is displayed
                if (WishList.auto() && mc.gameMode != null && mc.level.getGameTime() >= nextAutoUse) {
                    InteractionHand hand = null;
                    if (isKey(mc.player.getMainHandItem())) hand = InteractionHand.MAIN_HAND;
                    else if (isKey(mc.player.getOffhandItem())) hand = InteractionHand.OFF_HAND;
                    if (hand != null) {
                        InteractionResult r = mc.gameMode.useItemOn(mc.player, hand, hit);
                        if (r.consumesAction()) mc.player.swing(hand);
                        nextAutoUse = mc.level.getGameTime() + 40; // 2s cooldown
                    }
                }
            } else {
                lastMatchPos = null;
            }
        });

        // 2) Key guard: don't spend a key while the vault shows something you don't want
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!level.isClientSide() || !WishList.guard() || WishList.isEmpty()) return InteractionResult.PASS;
            ItemStack held = player.getItemInHand(hand);
            if (!held.is(Items.TRIAL_KEY) && !held.is(Items.OMINOUS_TRIAL_KEY)) return InteractionResult.PASS;
            ItemStack shown = displayedAt(level, hit.getBlockPos());
            if (shown.isEmpty()) return InteractionResult.PASS; // not a vault / nothing displayed
            if (WishList.contains(idOf(shown))) return InteractionResult.PASS;
            player.displayClientMessage(
                    Component.literal("Vault Wish: not wanted (").append(shown.getHoverName())
                            .append(Component.literal("). Key saved. /vaultwish guard off to disable.")), true);
            return InteractionResult.FAIL;
        });
    }

    private static ItemStack displayedAt(Level level, BlockPos pos) {
        if (level.getBlockEntity(pos) instanceof VaultBlockEntity vault) {
            return vault.getSharedData().getDisplayItem();
        }
        return ItemStack.EMPTY;
    }

    private static boolean isKey(ItemStack s) {
        return s.is(Items.TRIAL_KEY) || s.is(Items.OMINOUS_TRIAL_KEY);
    }

    private static List<String> itemNames;   // short names for suggestions
    private static Set<String> itemIds;      // full ids for validation

    private static void buildItemCache() {
        if (itemIds != null) return;
        itemNames = new ArrayList<>();
        itemIds = new HashSet<>();
        for (var key : BuiltInRegistries.ITEM.keySet()) {
            String full = key.toString();
            itemIds.add(full);
            itemNames.add(full.startsWith("minecraft:") ? full.substring("minecraft:".length()) : full);
        }
    }

    /** "mace" -> "minecraft:mace"; returns null if no such item exists. */
    private static String resolveItemId(String raw) {
        buildItemCache();
        String id = raw.trim().toLowerCase().replace(' ', '_');
        if (!id.contains(":")) id = "minecraft:" + id;
        return itemIds.contains(id) ? id : null;
    }

    private static String idOf(ItemStack stack) {
        return BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
    }

    private void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(ClientCommandManager.literal("vaultwish")
                .then(ClientCommandManager.literal("add").executes(ctx -> {
                    ItemStack held = Minecraft.getInstance().player.getMainHandItem();
                    if (held.isEmpty()) {
                        ctx.getSource().sendFeedback(Component.literal("Hold the item you want in your main hand."));
                        return 0;
                    }
                    String id = idOf(held);
                    ctx.getSource().sendFeedback(Component.literal(
                            WishList.add(id) ? "Added " + id : id + " is already on the list"));
                    return Command.SINGLE_SUCCESS;
                }))
                .then(ClientCommandManager.literal("addid")
                    .then(ClientCommandManager.argument("item", StringArgumentType.greedyString())
                        .suggests((ctx, builder) -> {
                            buildItemCache();
                            return SharedSuggestionProvider.suggest(itemNames.stream(), builder);
                        })
                        .executes(ctx -> {
                            String raw = StringArgumentType.getString(ctx, "item");
                            String id = resolveItemId(raw);
                            if (id == null) {
                                ctx.getSource().sendFeedback(Component.literal("Unknown item: " + raw));
                                return 0;
                            }
                            ctx.getSource().sendFeedback(Component.literal(
                                    WishList.add(id) ? "Added " + id : id + " is already on the list"));
                            return Command.SINGLE_SUCCESS;
                        })))
                .then(ClientCommandManager.literal("removeid")
                    .then(ClientCommandManager.argument("item", StringArgumentType.greedyString())
                        .suggests((ctx, builder) -> SharedSuggestionProvider.suggest(
                                WishList.all().stream().map(i -> i.startsWith("minecraft:") ? i.substring(10) : i), builder))
                        .executes(ctx -> {
                            String raw = StringArgumentType.getString(ctx, "item");
                            String id = resolveItemId(raw);
                            if (id == null) {
                                ctx.getSource().sendFeedback(Component.literal("Unknown item: " + raw));
                                return 0;
                            }
                            ctx.getSource().sendFeedback(Component.literal(
                                    WishList.remove(id) ? "Removed " + id : id + " was not on the list"));
                            return Command.SINGLE_SUCCESS;
                        })))
                .then(ClientCommandManager.literal("addvault").executes(ctx -> {
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.hitResult instanceof BlockHitResult hit && hit.getType() == HitResult.Type.BLOCK) {
                        ItemStack shown = displayedAt(mc.level, hit.getBlockPos());
                        if (!shown.isEmpty()) {
                            String id = idOf(shown);
                            ctx.getSource().sendFeedback(Component.literal(
                                    WishList.add(id) ? "Added " + id : id + " is already on the list"));
                            return Command.SINGLE_SUCCESS;
                        }
                    }
                    ctx.getSource().sendFeedback(Component.literal("Look at a vault that is showing an item."));
                    return 0;
                }))
                .then(ClientCommandManager.literal("remove").executes(ctx -> {
                    ItemStack held = Minecraft.getInstance().player.getMainHandItem();
                    String id = idOf(held);
                    ctx.getSource().sendFeedback(Component.literal(
                            WishList.remove(id) ? "Removed " + id : id + " was not on the list"));
                    return Command.SINGLE_SUCCESS;
                }))
                .then(ClientCommandManager.literal("list").executes(ctx -> {
                    ctx.getSource().sendFeedback(Component.literal(WishList.isEmpty()
                            ? "Wish list is empty."
                            : "Wish list: " + String.join(", ", WishList.all())));
                    return Command.SINGLE_SUCCESS;
                }))
                .then(ClientCommandManager.literal("clear").executes(ctx -> {
                    WishList.clear();
                    ctx.getSource().sendFeedback(Component.literal("Wish list cleared."));
                    return Command.SINGLE_SUCCESS;
                }))
                .then(ClientCommandManager.literal("auto")
                    .then(ClientCommandManager.literal("on").executes(ctx -> {
                        WishList.setAuto(true);
                        ctx.getSource().sendFeedback(Component.literal("Auto-use key ON"));
                        return Command.SINGLE_SUCCESS;
                    }))
                    .then(ClientCommandManager.literal("off").executes(ctx -> {
                        WishList.setAuto(false);
                        ctx.getSource().sendFeedback(Component.literal("Auto-use key OFF"));
                        return Command.SINGLE_SUCCESS;
                    })))
                .then(ClientCommandManager.literal("guard")
                    .then(ClientCommandManager.literal("on").executes(ctx -> {
                        WishList.setGuard(true);
                        ctx.getSource().sendFeedback(Component.literal("Key guard ON"));
                        return Command.SINGLE_SUCCESS;
                    }))
                    .then(ClientCommandManager.literal("off").executes(ctx -> {
                        WishList.setGuard(false);
                        ctx.getSource().sendFeedback(Component.literal("Key guard OFF"));
                        return Command.SINGLE_SUCCESS;
                    })))
            ));
    }
}
