package com.vaultwish;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashSet;
import java.util.Set;

/** Stores wanted item ids (e.g. "minecraft:mace") in config/vaultwish.json. */
public final class WishList {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("vaultwish.json");

    private static final class Data {
        Set<String> items = new LinkedHashSet<>();
        boolean guard = true;
        boolean auto = false;
    }

    private static Data data = new Data();

    private WishList() {}

    public static void load() {
        if (!Files.exists(FILE)) return;
        try (Reader r = Files.newBufferedReader(FILE)) {
            Data d = GSON.fromJson(r, Data.class);
            if (d != null && d.items != null) data = d;
        } catch (Exception e) {
            VaultWishClient.LOGGER.warn("Could not read vaultwish.json", e);
        }
    }

    private static void save() {
        try (Writer w = Files.newBufferedWriter(FILE)) {
            GSON.toJson(data, w);
        } catch (Exception e) {
            VaultWishClient.LOGGER.warn("Could not save vaultwish.json", e);
        }
    }

    public static boolean add(String id) { boolean c = data.items.add(id); save(); return c; }
    public static boolean remove(String id) { boolean c = data.items.remove(id); save(); return c; }
    public static void clear() { data.items.clear(); save(); }
    public static boolean contains(String id) { return data.items.contains(id); }
    public static boolean isEmpty() { return data.items.isEmpty(); }
    public static Set<String> all() { return data.items; }
    public static boolean guard() { return data.guard; }
    public static void setGuard(boolean g) { data.guard = g; save(); }
    public static boolean auto() { return data.auto; }
    public static void setAuto(boolean a) { data.auto = a; save(); }
}
